import React from 'react'
import './Header.css'
import {useState} from "react"
import AddTranscations from './AddTranscations'
export default function Balance({  income, expense }) {

  
     
        const bal = income - expense; 





    return (
    <>
    <div className='balance'>
        <div className='card1'>
        <h4>Your Balance</h4>
        <h1 h1 id="balance">₹0.00</h1>
        </div>
         <div className='card2'>
            <button className='btn'> Add</button>
            </div>
        
     
     </div>
    </>
  )
}
