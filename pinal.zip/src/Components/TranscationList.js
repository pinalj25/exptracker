import React from 'react'
import AddTranscations from './AddTranscations'
export default function TranscationList({transactions}) {
  return (
    <>
     <div>
    <h2>Transaction List</h2>
    <ul>
      {transactions.map((transaction, index) => (
        <li key={index}>
          {transaction.date} - {transaction.category} - {transaction.transactionType} - ${transaction.amount}-{transaction.details}
        </li>
      ))}
    </ul>
  </div>
  </>
  )
}
