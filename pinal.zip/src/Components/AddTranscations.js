import React,{useState} from 'react'
import styled from "styled-components";
import './Adt.css' 


export default function AddTranscations({ addTransaction  }) {
  const [date, setDate] = useState('');
  const [category, setCategory] = useState('');
  const [transactionType, setTransactionType] = useState('Income');
  const [amount, setAmount] = useState('');
  const[details,setDetails]=useState('')
 
  const handleAddTransaction = () => {
    // Validate input fields
    if (!date || !category || !amount || isNaN(parseFloat(amount))) {
      alert('Please fill in all fields with valid data.');
      return;
    }

    // Convert amount to a number
    const parsedAmount = parseFloat(amount);

    // Pass the transaction data to the parent component
    addTransaction({ date, category, transactionType, amount: parsedAmount });

    // Reset form fields
    setDate('');
    setCategory('');
    setTransactionType('Income');
    setAmount('');
    
  };
    
  // const addTransaction = () => { 
  //   AddTransactions({ 
  //     amount: Number(amount), 
  //     details, 
  //     transactionType, 
  //     id: Date.now(), 
  //   }); 
   
  // }; 
  // const closeModal = () => {
  //   // Close the modal
  //   setModalVisible(false);
  // };
  return (
    <div>
      <h2>Add Transaction</h2>
      <div>
        <label>Date:</label>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      </div>
      <div>
        <label>Category:</label>
        <input type="text" value={category} onChange={(e) => setCategory(e.target.value)} />
      </div>
      <div>
        <label>Transaction Type:</label>
        <select value={transactionType} onChange={(e) => setTransactionType(e.target.value)}>
          <option value="Income">Income</option>
          <option value="Expense">Expense</option>
        </select>
      </div>
      <div>
        <label>Amount:</label>
        <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
      </div>
      <button onClick={handleAddTransaction}>Add Transaction</button>
     
    

    </div>
  )

}