import React from 'react';
import './Header.css'

export default function Header() {
  return (
    <div>
       
       <h2>Expense Mate</h2>
    </div>
  )
}
